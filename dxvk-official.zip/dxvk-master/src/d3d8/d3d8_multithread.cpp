#include "d3d8_device.h"

namespace dxvk {

  D3D8Multithread::D3D8Multithread(
          BOOL                  Protected)
    : m_protected( Protected ) { }

}