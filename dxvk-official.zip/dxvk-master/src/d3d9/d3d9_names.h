#include "d3d9_include.h"

namespace dxvk {

  std::ostream& operator << (std::ostream& os, D3DRENDERSTATETYPE e);

}