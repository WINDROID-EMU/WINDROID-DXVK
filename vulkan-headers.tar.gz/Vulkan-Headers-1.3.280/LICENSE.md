Copyright 2015-2023 The Khronos Group Inc.

Files in this repository fall under one of these licenses:

- `Apache-2.0`
- `MIT`

Note: With the exception of `parse_dependency.py` the files using `MIT` license
also fall under `Apache-2.0`. Example:

```
SPDX-License-Identifier: Apache-2.0 OR MIT
```

Full license text of these licenses is available at:

  * Apache-2.0: https://opensource.org/licenses/Apache-2.0
  * MIT: https://opensource.org/licenses/MIT
